<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.13.0/dist/sweetalert2.all.min.js" integrity="sha256-J9avsZWTdcAPp1YASuhlEH42nySYLmm0Jw1txwkuqQw=" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<body>
<script>

Swal.fire({
  icon: 'error',
  title: 'Oops...',
  html: 'Something went wrong! '+'<br>'+
  'Please check Your <b>Email</b> Or <b>Password</b>'

})
</script>
</body>
</html>